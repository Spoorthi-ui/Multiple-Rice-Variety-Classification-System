# !pip install transformers==4.50.0

# ============================================================
# 🌾 RICE CLASSIFICATION — SigLIP2-Base (Google, Feb 2025)
# ============================================================
# COMPLETE CODE WITH ALL METRICS, GRAPHS & SAVING
# Model: google/siglip2-base-patch16-384 (0.4B params)
# Paper: arxiv.org/abs/2502.14786
# Expected: ~25 min on P100, 99%+ accuracy
# ============================================================

import os, random, time, json
import numpy as np
import torch
import joblib
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from transformers import AutoProcessor, AutoModel
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, 
    classification_report,
    confusion_matrix, 
    ConfusionMatrixDisplay,
    precision_recall_fscore_support,
    roc_curve,
    auc,
    precision_recall_curve,
    average_precision_score
)
from sklearn.preprocessing import label_binarize
import matplotlib.pyplot as plt
import seaborn as sns

# ============================================================
# SETUP & CONFIG
# ============================================================
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

DATASET_PATH = "/kaggle/input/datasets/muratkokludataset/rice-image-dataset/Rice_Image_Dataset"
MODEL_NAME   = "google/siglip2-base-patch16-384"
BATCH_SIZE   = 256
NUM_WORKERS  = 4
DEVICE       = "cuda" if torch.cuda.is_available() else "cpu"

print("=" * 60)
print("🌾 RICE CLASSIFICATION WITH SigLIP2")
print("=" * 60)
print(f"Device  : {DEVICE}")
print(f"GPU     : {torch.cuda.get_device_name(0) if DEVICE == 'cuda' else 'None'}")
print(f"Model   : {MODEL_NAME}")
print("=" * 60)


# ============================================================
# LOAD MODEL
# ============================================================
print(f"\n📦 Loading SigLIP2-Base ...")
t0 = time.time()

processor = AutoProcessor.from_pretrained(MODEL_NAME)
backbone  = AutoModel.from_pretrained(MODEL_NAME, torch_dtype=torch.float16).to(DEVICE)
backbone.eval()

for param in backbone.parameters():
    param.requires_grad = False

params_m = sum(p.numel() for p in backbone.parameters()) / 1e6
print(f"✅ Loaded in {time.time()-t0:.1f}s  ({params_m:.0f}M params, frozen)")


# ============================================================
# BUILD DATASET
# ============================================================
classes = sorted([
    d for d in os.listdir(DATASET_PATH)
    if os.path.isdir(os.path.join(DATASET_PATH, d))
])
class_to_idx = {c: i for i, c in enumerate(classes)}
idx_to_class = {i: c for c, i in class_to_idx.items()}
num_classes  = len(classes)

print(f"\n📂 Classes ({num_classes}): {classes}")

all_files, all_labels = [], []
for cls in classes:
    cls_path = os.path.join(DATASET_PATH, cls)
    for fname in os.listdir(cls_path):
        if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
            all_files.append(os.path.join(cls_path, fname))
            all_labels.append(class_to_idx[cls])

print(f"📊 Total images found: {len(all_files):,}")

# Shuffle and split
combined = list(zip(all_files, all_labels))
random.shuffle(combined)
all_files, all_labels = map(list, zip(*combined))

n       = len(all_files)
n_train = int(0.80 * n)
n_val   = int(0.10 * n)

train_files, train_labels = all_files[:n_train],              all_labels[:n_train]
val_files,   val_labels   = all_files[n_train:n_train+n_val], all_labels[n_train:n_train+n_val]
test_files,  test_labels  = all_files[n_train+n_val:],        all_labels[n_train+n_val:]

print(f"\n📈 Data Split:")
print(f"   Train : {len(train_files):,} ({len(train_files)/n*100:.1f}%)")
print(f"   Val   : {len(val_files):,} ({len(val_files)/n*100:.1f}%)")
print(f"   Test  : {len(test_files):,} ({len(test_files)/n*100:.1f}%)")


# ============================================================
# DATASET CLASS
# ============================================================
class RiceDataset(Dataset):
    def __init__(self, files, labels, processor):
        self.files     = files
        self.labels    = labels
        self.processor = processor
    
    def __len__(self): 
        return len(self.files)
    
    def __getitem__(self, idx):
        img    = Image.open(self.files[idx]).convert('RGB')
        inputs = self.processor(images=img, return_tensors='pt')
        return inputs['pixel_values'].squeeze(0), self.labels[idx]

train_loader = DataLoader(RiceDataset(train_files, train_labels, processor),
                          batch_size=BATCH_SIZE, shuffle=False,
                          num_workers=NUM_WORKERS, pin_memory=True)
val_loader   = DataLoader(RiceDataset(val_files, val_labels, processor),
                          batch_size=BATCH_SIZE, shuffle=False,
                          num_workers=NUM_WORKERS, pin_memory=True)
test_loader  = DataLoader(RiceDataset(test_files, test_labels, processor),
                          batch_size=BATCH_SIZE, shuffle=False,
                          num_workers=NUM_WORKERS, pin_memory=True)


# ============================================================
# FEATURE EXTRACTION
# ============================================================
def extract_features(loader, tag=""):
    feats, labs = [], []
    total = len(loader)
    with torch.no_grad(), torch.amp.autocast('cuda'):
        for i, (pixels, labels) in enumerate(loader):
            pixels = pixels.to(DEVICE, dtype=torch.float16)
            out = backbone.vision_model(pixel_values=pixels)
            emb = out.pooler_output
            feats.append(emb.cpu().float().numpy())
            labs.extend(labels.numpy())
            if (i+1) % 10 == 0 or (i+1) == total:
                pct = (i+1) / total * 100
                print(f"   [{tag}] batch {i+1}/{total} ({pct:.0f}%)")
    return np.concatenate(feats, axis=0), np.array(labs)

print("\n⚡ Extracting features from all images...")
t1 = time.time()

X_train, y_train = extract_features(train_loader, "Train")
print(f"   ✅ Train features: {X_train.shape}")

X_val, y_val = extract_features(val_loader, "Val  ")
print(f"   ✅ Val features: {X_val.shape}")

X_test, y_test = extract_features(test_loader, "Test ")
print(f"   ✅ Test features: {X_test.shape}")

extraction_time = time.time() - t1
print(f"\n✅ Feature extraction done in {extraction_time/60:.1f} minutes")
print(f"   Feature dimension: {X_train.shape[1]}")


# ============================================================
# TRAIN CLASSIFIER
# ============================================================
print("\n🧠 Training linear classifier...")
t2 = time.time()

clf = LogisticRegression(
    solver='lbfgs',
    max_iter=1000,
    C=1.0,
    n_jobs=-1
)
clf.fit(X_train, y_train)

train_time = time.time() - t2
print(f"✅ Trained in {train_time:.1f} seconds")


# ============================================================
# PREDICTIONS & PROBABILITIES
# ============================================================
print("\n🔮 Generating predictions...")

# Training predictions
train_preds = clf.predict(X_train)
train_probs = clf.predict_proba(X_train)
train_acc   = accuracy_score(y_train, train_preds)

# Validation predictions
val_preds = clf.predict(X_val)
val_probs = clf.predict_proba(X_val)
val_acc   = accuracy_score(y_val, val_preds)

# Test predictions
test_preds = clf.predict(X_test)
test_probs = clf.predict_proba(X_test)
test_acc   = accuracy_score(y_test, test_preds)


# ============================================================
# COMPREHENSIVE METRICS
# ============================================================
print("\n" + "=" * 60)
print("📊 COMPREHENSIVE METRICS")
print("=" * 60)

# Accuracy Summary
print(f"\n🎯 ACCURACY SUMMARY:")
print(f"   Train Accuracy : {train_acc * 100:.2f}%")
print(f"   Val Accuracy   : {val_acc * 100:.2f}%")
print(f"   Test Accuracy  : {test_acc * 100:.2f}%")

# Per-class metrics
precision, recall, f1, support = precision_recall_fscore_support(
    y_test, test_preds, average=None, labels=range(num_classes)
)

print(f"\n📋 PER-CLASS METRICS (Test Set):")
print("-" * 60)
print(f"{'Class':<15} {'Precision':>10} {'Recall':>10} {'F1-Score':>10} {'Support':>10}")
print("-" * 60)
for i, cls in enumerate(classes):
    print(f"{cls:<15} {precision[i]:>10.4f} {recall[i]:>10.4f} {f1[i]:>10.4f} {support[i]:>10}")
print("-" * 60)

# Macro and Weighted averages
prec_macro, rec_macro, f1_macro, _ = precision_recall_fscore_support(
    y_test, test_preds, average='macro'
)
prec_weighted, rec_weighted, f1_weighted, _ = precision_recall_fscore_support(
    y_test, test_preds, average='weighted'
)

print(f"{'Macro Avg':<15} {prec_macro:>10.4f} {rec_macro:>10.4f} {f1_macro:>10.4f}")
print(f"{'Weighted Avg':<15} {prec_weighted:>10.4f} {rec_weighted:>10.4f} {f1_weighted:>10.4f}")
print("-" * 60)

# Full classification report
print(f"\n📋 FULL CLASSIFICATION REPORT:")
print(classification_report(y_test, test_preds, target_names=classes, digits=4))


# ============================================================
# VISUALIZATION 1: CLASS DISTRIBUTION
# ============================================================
print("\n🎨 Generating visualizations...")

fig, axes = plt.subplots(1, 3, figsize=(18, 5))
fig.patch.set_facecolor('#0f0f0f')

for ax, (data, title) in zip(axes, [
    (train_labels, 'Train Set'),
    (val_labels, 'Validation Set'),
    (test_labels, 'Test Set')
]):
    counts = [data.count(i) if isinstance(data, list) else np.sum(data == i) for i in range(num_classes)]
    bars = ax.bar(classes, counts, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'])
    ax.set_facecolor('#1a1a1a')
    ax.set_title(f'{title} Distribution', color='white', fontsize=12, pad=10)
    ax.set_xlabel('Rice Type', color='white')
    ax.set_ylabel('Count', color='white')
    ax.tick_params(colors='white')
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right', color='white')
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 50,
                f'{count:,}', ha='center', va='bottom', color='white', fontsize=9)

plt.tight_layout()
plt.savefig('class_distribution.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 2: CONFUSION MATRIX
# ============================================================
fig, ax = plt.subplots(figsize=(10, 8))
fig.patch.set_facecolor('#0f0f0f')
ax.set_facecolor('#1a1a1a')

cm = confusion_matrix(y_test, test_preds)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=classes)
disp.plot(ax=ax, colorbar=True, cmap='Blues')

ax.set_title(f'Confusion Matrix — Test Accuracy: {test_acc*100:.2f}%',
             color='white', fontsize=14, pad=15)
ax.tick_params(colors='white')
ax.xaxis.label.set_color('white')
ax.yaxis.label.set_color('white')
plt.setp(ax.get_xticklabels(), rotation=45, ha='right', color='white')
plt.setp(ax.get_yticklabels(), color='white')

plt.tight_layout()
plt.savefig('confusion_matrix.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 3: NORMALIZED CONFUSION MATRIX
# ============================================================
fig, ax = plt.subplots(figsize=(10, 8))
fig.patch.set_facecolor('#0f0f0f')
ax.set_facecolor('#1a1a1a')

cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
sns.heatmap(cm_normalized, annot=True, fmt='.2%', cmap='Blues',
            xticklabels=classes, yticklabels=classes, ax=ax,
            annot_kws={'color': 'black', 'fontsize': 10})

ax.set_title('Normalized Confusion Matrix (Percentages)', color='white', fontsize=14, pad=15)
ax.set_xlabel('Predicted Label', color='white')
ax.set_ylabel('True Label', color='white')
ax.tick_params(colors='white')
plt.setp(ax.get_xticklabels(), rotation=45, ha='right', color='white')
plt.setp(ax.get_yticklabels(), rotation=0, color='white')

plt.tight_layout()
plt.savefig('confusion_matrix_normalized.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 4: PER-CLASS METRICS BAR CHART
# ============================================================
fig, ax = plt.subplots(figsize=(12, 6))
fig.patch.set_facecolor('#0f0f0f')
ax.set_facecolor('#1a1a1a')

x = np.arange(num_classes)
width = 0.25

bars1 = ax.bar(x - width, precision, width, label='Precision', color='#FF6B6B')
bars2 = ax.bar(x, recall, width, label='Recall', color='#4ECDC4')
bars3 = ax.bar(x + width, f1, width, label='F1-Score', color='#45B7D1')

ax.set_xlabel('Rice Type', color='white', fontsize=12)
ax.set_ylabel('Score', color='white', fontsize=12)
ax.set_title('Per-Class Performance Metrics', color='white', fontsize=14, pad=15)
ax.set_xticks(x)
ax.set_xticklabels(classes, color='white')
ax.tick_params(colors='white')
ax.legend(facecolor='#2a2a2a', edgecolor='white', labelcolor='white')
ax.set_ylim(0.95, 1.01)
ax.axhline(y=1.0, color='white', linestyle='--', alpha=0.3)

# Add value labels
for bars in [bars1, bars2, bars3]:
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.3f}', ha='center', va='bottom',
                color='white', fontsize=8)

plt.tight_layout()
plt.savefig('per_class_metrics.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 5: ROC CURVES (One-vs-Rest)
# ============================================================
y_test_bin = label_binarize(y_test, classes=range(num_classes))

fig, ax = plt.subplots(figsize=(10, 8))
fig.patch.set_facecolor('#0f0f0f')
ax.set_facecolor('#1a1a1a')

colors_roc = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']

for i, (cls, color) in enumerate(zip(classes, colors_roc)):
    fpr, tpr, _ = roc_curve(y_test_bin[:, i], test_probs[:, i])
    roc_auc = auc(fpr, tpr)
    ax.plot(fpr, tpr, color=color, lw=2, label=f'{cls} (AUC = {roc_auc:.4f})')

ax.plot([0, 1], [0, 1], 'w--', lw=1, alpha=0.5)
ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('False Positive Rate', color='white', fontsize=12)
ax.set_ylabel('True Positive Rate', color='white', fontsize=12)
ax.set_title('ROC Curves (One-vs-Rest)', color='white', fontsize=14, pad=15)
ax.legend(loc='lower right', facecolor='#2a2a2a', edgecolor='white', labelcolor='white')
ax.tick_params(colors='white')
ax.grid(True, alpha=0.2, color='white')

plt.tight_layout()
plt.savefig('roc_curves.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 6: PRECISION-RECALL CURVES
# ============================================================
fig, ax = plt.subplots(figsize=(10, 8))
fig.patch.set_facecolor('#0f0f0f')
ax.set_facecolor('#1a1a1a')

for i, (cls, color) in enumerate(zip(classes, colors_roc)):
    prec_curve, rec_curve, _ = precision_recall_curve(y_test_bin[:, i], test_probs[:, i])
    ap = average_precision_score(y_test_bin[:, i], test_probs[:, i])
    ax.plot(rec_curve, prec_curve, color=color, lw=2, label=f'{cls} (AP = {ap:.4f})')

ax.set_xlim([0.0, 1.0])
ax.set_ylim([0.0, 1.05])
ax.set_xlabel('Recall', color='white', fontsize=12)
ax.set_ylabel('Precision', color='white', fontsize=12)
ax.set_title('Precision-Recall Curves', color='white', fontsize=14, pad=15)
ax.legend(loc='lower left', facecolor='#2a2a2a', edgecolor='white', labelcolor='white')
ax.tick_params(colors='white')
ax.grid(True, alpha=0.2, color='white')

plt.tight_layout()
plt.savefig('precision_recall_curves.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 7: CONFIDENCE DISTRIBUTION
# ============================================================
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.patch.set_facecolor('#0f0f0f')

# Correct predictions confidence
correct_mask = test_preds == y_test
correct_conf = np.max(test_probs[correct_mask], axis=1)
wrong_conf   = np.max(test_probs[~correct_mask], axis=1) if np.sum(~correct_mask) > 0 else np.array([])

ax1 = axes[0]
ax1.set_facecolor('#1a1a1a')
ax1.hist(correct_conf, bins=50, color='#4ECDC4', alpha=0.8, edgecolor='white', linewidth=0.5)
ax1.set_xlabel('Confidence', color='white', fontsize=12)
ax1.set_ylabel('Count', color='white', fontsize=12)
ax1.set_title(f'Correct Predictions Confidence (n={len(correct_conf):,})', color='white', fontsize=12, pad=10)
ax1.tick_params(colors='white')
ax1.axvline(x=np.mean(correct_conf), color='#FF6B6B', linestyle='--', lw=2, label=f'Mean: {np.mean(correct_conf):.3f}')
ax1.legend(facecolor='#2a2a2a', edgecolor='white', labelcolor='white')

ax2 = axes[1]
ax2.set_facecolor('#1a1a1a')
if len(wrong_conf) > 0:
    ax2.hist(wrong_conf, bins=20, color='#FF6B6B', alpha=0.8, edgecolor='white', linewidth=0.5)
    ax2.axvline(x=np.mean(wrong_conf), color='#4ECDC4', linestyle='--', lw=2, label=f'Mean: {np.mean(wrong_conf):.3f}')
    ax2.legend(facecolor='#2a2a2a', edgecolor='white', labelcolor='white')
else:
    ax2.text(0.5, 0.5, 'No wrong predictions!', ha='center', va='center',
             color='#4ECDC4', fontsize=14, transform=ax2.transAxes)
ax2.set_xlabel('Confidence', color='white', fontsize=12)
ax2.set_ylabel('Count', color='white', fontsize=12)
ax2.set_title(f'Wrong Predictions Confidence (n={len(wrong_conf):,})', color='white', fontsize=12, pad=10)
ax2.tick_params(colors='white')

plt.tight_layout()
plt.savefig('confidence_distribution.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 8: SAMPLE PREDICTIONS GRID
# ============================================================
fig, axes = plt.subplots(4, 6, figsize=(18, 12))
fig.patch.set_facecolor('#0f0f0f')

sample_idxs = random.sample(range(len(test_files)), 24)
colors_pred = ['#4ECDC4', '#FF6B6B']  # teal=correct, red=wrong

for ax, idx in zip(axes.flatten(), sample_idxs):
    img     = Image.open(test_files[idx]).convert('RGB')
    true    = classes[test_labels[idx]]
    pred    = classes[test_preds[idx]]
    conf    = np.max(test_probs[idx]) * 100
    correct = true == pred

    ax.imshow(img)
    ax.axis('off')
    c = colors_pred[0] if correct else colors_pred[1]
    ax.set_title(f"True: {true}\nPred: {pred}\nConf: {conf:.1f}%", 
                 color=c, fontsize=8, pad=3)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_edgecolor(c)
        spine.set_linewidth(3)

plt.suptitle('Sample Predictions  [🟢 Teal = Correct   🔴 Red = Wrong]',
             color='white', fontsize=14, y=1.02)
plt.tight_layout()
plt.savefig('sample_predictions.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# VISUALIZATION 9: MISCLASSIFIED SAMPLES (if any)
# ============================================================
wrong_indices = np.where(test_preds != y_test)[0]

if len(wrong_indices) > 0:
    n_show = min(12, len(wrong_indices))
    fig, axes = plt.subplots(2, 6, figsize=(18, 6))
    fig.patch.set_facecolor('#0f0f0f')
    
    for i, ax in enumerate(axes.flatten()):
        if i < n_show:
            idx  = wrong_indices[i]
            img  = Image.open(test_files[idx]).convert('RGB')
            true = classes[test_labels[idx]]
            pred = classes[test_preds[idx]]
            conf = np.max(test_probs[idx]) * 100
            
            ax.imshow(img)
            ax.set_title(f"True: {true}\nPred: {pred}\nConf: {conf:.1f}%",
                        color='#FF6B6B', fontsize=9, pad=3)
            for spine in ax.spines.values():
                spine.set_visible(True)
                spine.set_edgecolor('#FF6B6B')
                spine.set_linewidth(3)
        ax.axis('off')
    
    plt.suptitle(f'Misclassified Samples ({len(wrong_indices)} total errors)',
                 color='#FF6B6B', fontsize=14, y=1.02)
    plt.tight_layout()
    plt.savefig('misclassified_samples.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
    plt.show()
else:
    print("🎉 No misclassified samples to show!")


# ============================================================
# VISUALIZATION 10: MODEL SUMMARY DASHBOARD
# ============================================================
fig = plt.figure(figsize=(16, 10))
fig.patch.set_facecolor('#0f0f0f')

# Create grid
gs = fig.add_gridspec(3, 4, hspace=0.4, wspace=0.3)

# Title
fig.suptitle('🌾 Rice Classification — SigLIP2-Base Model Summary', 
             color='white', fontsize=18, fontweight='bold', y=0.98)

# Accuracy gauge (text-based)
ax1 = fig.add_subplot(gs[0, 0])
ax1.set_facecolor('#1a1a1a')
ax1.text(0.5, 0.6, f'{test_acc*100:.2f}%', ha='center', va='center',
         fontsize=36, color='#4ECDC4', fontweight='bold', transform=ax1.transAxes)
ax1.text(0.5, 0.2, 'Test Accuracy', ha='center', va='center',
         fontsize=12, color='white', transform=ax1.transAxes)
ax1.set_xlim(0, 1); ax1.set_ylim(0, 1)
ax1.axis('off')

# Model info
ax2 = fig.add_subplot(gs[0, 1])
ax2.set_facecolor('#1a1a1a')
info_text = f"""Model: SigLIP2-Base
Params: {params_m:.0f}M (frozen)
Feature Dim: {X_train.shape[1]}
Input Size: 384×384"""
ax2.text(0.1, 0.5, info_text, ha='left', va='center',
         fontsize=11, color='white', transform=ax2.transAxes, family='monospace')
ax2.set_xlim(0, 1); ax2.set_ylim(0, 1)
ax2.axis('off')

# Dataset info
ax3 = fig.add_subplot(gs[0, 2])
ax3.set_facecolor('#1a1a1a')
data_text = f"""Classes: {num_classes}
Total Images: {n:,}
Train: {len(train_files):,}
Val: {len(val_files):,}
Test: {len(test_files):,}"""
ax3.text(0.1, 0.5, data_text, ha='left', va='center',
         fontsize=11, color='white', transform=ax3.transAxes, family='monospace')
ax3.set_xlim(0, 1); ax3.set_ylim(0, 1)
ax3.axis('off')

# Timing info
ax4 = fig.add_subplot(gs[0, 3])
ax4.set_facecolor('#1a1a1a')
time_text = f"""Extract: {extraction_time/60:.1f} min
Train: {train_time:.1f} sec
Total: {(extraction_time + train_time)/60:.1f} min"""
ax4.text(0.1, 0.5, time_text, ha='left', va='center',
         fontsize=11, color='white', transform=ax4.transAxes, family='monospace')
ax4.set_xlim(0, 1); ax4.set_ylim(0, 1)
ax4.axis('off')

# Mini confusion matrix
ax5 = fig.add_subplot(gs[1:, :2])
ax5.set_facecolor('#1a1a1a')
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=classes, yticklabels=classes, ax=ax5,
            annot_kws={'color': 'black', 'fontsize': 10})
ax5.set_title('Confusion Matrix', color='white', fontsize=12, pad=10)
ax5.set_xlabel('Predicted', color='white')
ax5.set_ylabel('True', color='white')
ax5.tick_params(colors='white')
plt.setp(ax5.get_xticklabels(), rotation=45, ha='right', color='white', fontsize=9)
plt.setp(ax5.get_yticklabels(), rotation=0, color='white', fontsize=9)

# Per-class metrics table
ax6 = fig.add_subplot(gs[1:, 2:])
ax6.set_facecolor('#1a1a1a')
ax6.axis('off')

table_data = []
for i, cls in enumerate(classes):
    table_data.append([cls, f'{precision[i]:.4f}', f'{recall[i]:.4f}', f'{f1[i]:.4f}', f'{support[i]:,}'])
table_data.append(['─'*8, '─'*8, '─'*8, '─'*8, '─'*8])
table_data.append(['Macro', f'{prec_macro:.4f}', f'{rec_macro:.4f}', f'{f1_macro:.4f}', ''])
table_data.append(['Weighted', f'{prec_weighted:.4f}', f'{rec_weighted:.4f}', f'{f1_weighted:.4f}', ''])

table = ax6.table(cellText=table_data,
                  colLabels=['Class', 'Precision', 'Recall', 'F1-Score', 'Support'],
                  loc='center', cellLoc='center')
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1.2, 1.5)

for key, cell in table.get_celld().items():
    cell.set_facecolor('#2a2a2a')
    cell.set_text_props(color='white')
    cell.set_edgecolor('white')
    if key[0] == 0:  # Header
        cell.set_facecolor('#4ECDC4')
        cell.set_text_props(color='black', fontweight='bold')

ax6.set_title('Performance Metrics', color='white', fontsize=12, pad=10)

plt.savefig('model_summary_dashboard.png', bbox_inches='tight', facecolor='#0f0f0f', dpi=150)
plt.show()


# ============================================================
# SAVE FOR DEPLOYMENT
# ============================================================
print("\n" + "=" * 60)
print("💾 SAVING MODEL FOR DEPLOYMENT")
print("=" * 60)

# Save classifier
joblib.dump(clf, 'rice_classifier.joblib')

# Save comprehensive config
config = {
    "model_name": MODEL_NAME,
    "paper": "arxiv.org/abs/2502.14786",
    "classes": classes,
    "num_classes": num_classes,
    "feature_dim": int(X_train.shape[1]),
    "input_size": 384,
    "params_millions": float(params_m),
    "metrics": {
        "train_accuracy": float(train_acc),
        "val_accuracy": float(val_acc),
        "test_accuracy": float(test_acc),
        "precision_macro": float(prec_macro),
        "recall_macro": float(rec_macro),
        "f1_macro": float(f1_macro),
        "precision_weighted": float(prec_weighted),
        "recall_weighted": float(rec_weighted),
        "f1_weighted": float(f1_weighted),
        "per_class": {
            cls: {
                "precision": float(precision[i]),
                "recall": float(recall[i]),
                "f1_score": float(f1[i]),
                "support": int(support[i])
            } for i, cls in enumerate(classes)
        }
    },
    "dataset": {
        "total_images": n,
        "train_size": len(train_files),
        "val_size": len(val_files),
        "test_size": len(test_files)
    },
    "timing": {
        "extraction_minutes": float(extraction_time / 60),
        "training_seconds": float(train_time),
        "total_minutes": float((extraction_time + train_time) / 60)
    }
}

with open('model_config.json', 'w') as f:
    json.dump(config, f, indent=2)

# List saved files
saved_files = [
    'rice_classifier.joblib',
    'model_config.json',
    'class_distribution.png',
    'confusion_matrix.png',
    'confusion_matrix_normalized.png',
    'per_class_metrics.png',
    'roc_curves.png',
    'precision_recall_curves.png',
    'confidence_distribution.png',
    'sample_predictions.png',
    'model_summary_dashboard.png'
]

if len(wrong_indices) > 0:
    saved_files.append('misclassified_samples.png')

print("\n📁 Saved files:")
for f in saved_files:
    if os.path.exists(f):
        size = os.path.getsize(f)
        if size > 1024*1024:
            print(f"   ✅ {f} ({size/1024/1024:.1f} MB)")
        else:
            print(f"   ✅ {f} ({size/1024:.1f} KB)")


# ============================================================
# FINAL SUMMARY
# ============================================================
total_time = (time.time() - t1) / 60

print("\n" + "=" * 60)
print("🏆 FINAL SUMMARY")
print("=" * 60)
print(f"""
   Model         : SigLIP2-Base-patch16-384 (Google, Feb 2025)
   Paper         : arxiv.org/abs/2502.14786
   Parameters    : {params_m:.0f}M (frozen)
   Feature Dim   : {X_train.shape[1]}
   Input Size    : 384 × 384 pixels
   
   Dataset       : Rice Image Dataset
   Classes       : {num_classes} → {classes}
   Total Images  : {n:,}
   Split         : {len(train_files):,} / {len(val_files):,} / {len(test_files):,}
   
   ┌────────────────────────────────┐
   │  Train Accuracy : {train_acc*100:>6.2f}%     │
   │  Val Accuracy   : {val_acc*100:>6.2f}%     │
   │  Test Accuracy  : {test_acc*100:>6.2f}%     │
   └────────────────────────────────┘
   
   Macro F1      : {f1_macro:.4f}
   Weighted F1   : {f1_weighted:.4f}
   
   Errors        : {len(wrong_indices)} / {len(test_files)} ({len(wrong_indices)/len(test_files)*100:.2f}%)
   
   Extraction    : {extraction_time/60:.1f} min
   Training      : {train_time:.1f} sec
   Total Time    : {total_time:.1f} min
   
   HF Login      : NOT required ✅
""")
print("=" * 60)
print("\n📥 DOWNLOAD FROM KAGGLE OUTPUT:")
print("   • rice_classifier.joblib  (classifier)")
print("   • model_config.json       (config + metrics)")
print("   • All .png visualizations")
print("\n🚀 Ready for deployment!")
print("=" * 60)
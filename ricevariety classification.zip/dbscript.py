import mysql.connector

def setup_database():
    try:
        # Connect to MySQL (without database initially)
        db = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )
        cursor = db.cursor()

        # Drop and Recreate Database
        cursor.execute("DROP DATABASE IF EXISTS ricevariety_2026")
        cursor.execute("CREATE DATABASE ricevariety_2026")
        print("Database 'ricevariety_2026' created successfully.")

        # Switch to the new database
        cursor.execute("USE ricevariety_2026")

        # Create Users Table
        cursor.execute("""
            CREATE TABLE users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                fullname VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password VARCHAR(100) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("Table 'users' created successfully.")

        # Create History Table
        cursor.execute("""
            CREATE TABLE history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                filename VARCHAR(255) NOT NULL,
                result VARCHAR(100) NOT NULL,
                probability FLOAT NOT NULL,
                quality INT DEFAULT 0,
                origin VARCHAR(255),
                grain_type VARCHAR(100),
                broken_pct VARCHAR(50),
                cooking_use VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("Table 'history' created successfully.")

        db.commit()
        cursor.close()
        db.close()
        print("Database setup complete.")

    except mysql.connector.Error as err:
        print(f"Error: {err}")

if __name__ == "__main__":
    setup_database()

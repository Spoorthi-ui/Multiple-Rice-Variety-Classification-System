import os
import re
import json
import torch
import joblib
import numpy as np
import mysql.connector
import google.generativeai as genai
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
from PIL import Image
from transformers import AutoProcessor, AutoModel

app = Flask(__name__)
app.secret_key = "rice_variety_secret_key_2026"
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

# Gemini API Configuration
GEMINI_API_KEY = "AIzaSyDPdnlQynXOAwFwxogvsjs09oJONneGfWA"
genai.configure(api_key=GEMINI_API_KEY)
gemini_model = genai.GenerativeModel('gemini-2.5-flash')

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'ricevariety_2026'
}

def get_db_connection():
    return mysql.connector.connect(**db_config)

# Load Model Configuration and Models
print("Loading model and processor...")
with open('model/model_config.json', 'r') as f:
    model_config = json.load(f)

CLASSES = model_config['classes']
MODEL_NAME = model_config['model_name']
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

processor = AutoProcessor.from_pretrained(MODEL_NAME)
backbone = AutoModel.from_pretrained(MODEL_NAME).to(DEVICE)
backbone.eval()

# Load scikit-learn classifier
clf = joblib.load('model/rice_classifier.joblib')
print("Model loaded successfully.")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        fullname = request.form['fullname']
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (fullname, email, password) VALUES (%s, %s, %s)", (fullname, email, password))
            conn.commit()
            flash("Registration successful! Please login.", "success")
            return redirect(url_for('login'))
        except mysql.connector.Error as err:
            flash(f"Error: {err}", "danger")
        finally:
            cursor.close()
            conn.close()
            
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user:
            session['user_id'] = user['id']
            session['fullname'] = user['fullname']
            flash(f"Welcome back, {user['fullname']}!", "success")
            return redirect(url_for('predict'))
        else:
            flash("Invalid email or password.", "danger")

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for('login'))

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        if 'file' not in request.files:
            flash("No file part", "danger")
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash("No selected file", "danger")
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Inference
            img = Image.open(file_path).convert('RGB')
            inputs = processor(images=img, return_tensors='pt').to(DEVICE)
            
            with torch.no_grad():
                out = backbone.vision_model(pixel_values=inputs['pixel_values'])
                emb = out.pooler_output.cpu().numpy()
            
            probs = clf.predict_proba(emb)
            idx = np.argmax(probs[0])
            result = CLASSES[idx]
            probability = float(probs[0][idx]) * 100
            # Fetch details and quality from Gemini
            try:
                # Prepare the prompt for multimodal analysis
                prompt = (
                    f"Analyze the provided image of rice grains. The variety has been identified as '{result}'.\n"
                    f"Perform a detailed agricultural analysis and return ONLY a JSON object with the following keys:\n"
                    f"1. 'description': A professional description of the variety (100 words).\n"
                    f"2. 'quality_rating': Integer from 1 to 5.\n"
                    f"3. 'origin': Geographical origin or typical cultivation regions for this variety.\n"
                    f"4. 'grain_type': Physical classification (e.g., 'Long Slender', 'Short Bold', 'Medium Slender').\n"
                    f"5. 'broken_pct': Estimated percentage of broken grains seen in the image (e.g., '5-10%').\n"
                    f"6. 'cooking_use': Best culinary application (e.g., 'Premium Biryani', 'Daily Meals', 'Risotto')."
                )
                
                # Send both prompt and image for multimodal analysis
                response = gemini_model.generate_content([prompt, img])
                
                # Parse JSON response
                try:
                    # Remove markdown code blocks if present
                    clean_text = re.sub(r'```(?:json)?\s*|\s*```', '', response.text.strip())
                    ai_data = json.loads(clean_text)
                    ai_details = ai_data.get('description', "Details not available.")
                    quality_rating = ai_data.get('quality_rating', 0)
                    origin = ai_data.get('origin', 'Unknown')
                    grain_type = ai_data.get('grain_type', 'N/A')
                    broken_pct = ai_data.get('broken_pct', 'N/A')
                    cooking_use = ai_data.get('cooking_use', 'General')
                except Exception as parse_err:
                    print(f"JSON Parsing Error: {parse_err}. Raw response: {response.text}")
                    ai_details = response.text
                    quality_rating, origin, grain_type, broken_pct, cooking_use = 0, 'Unknown', 'N/A', 'N/A', 'General'
                    
            except Exception as e:
                ai_details = "Additional details could not be loaded at this time."
                quality_rating, origin, grain_type, broken_pct, cooking_use = 0, 'Unknown', 'N/A', 'N/A', 'General'
                print(f"Gemini Error: {e}")

            # Save to history with extended details
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO history (user_id, filename, result, probability, quality, origin, grain_type, broken_pct, cooking_use) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (session['user_id'], filename, result, probability, quality_rating, origin, grain_type, broken_pct, cooking_use))
            conn.commit()
            cursor.close()
            conn.close()

            return render_template('result.html', 
                                 result=result, 
                                 probability=f"{probability:.2f}", 
                                 filename=filename, 
                                 ai_details=ai_details, 
                                 quality_rating=quality_rating,
                                 origin=origin,
                                 grain_type=grain_type,
                                 broken_pct=broken_pct,
                                 cooking_use=cooking_use)
        else:
            flash("Invalid file type. Only JPG, JPEG, and PNG are allowed.", "danger")

    return render_template('predict.html')

@app.route('/history')
def history():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM history WHERE user_id = %s ORDER BY created_at DESC", (session['user_id'],))
    history_data = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('history.html', history=history_data)

if __name__ == '__main__':
    app.run(debug=True)
